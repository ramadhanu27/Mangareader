# Flavor Flavor WordPress Theme

A modern manga/manhwa reader theme converted from ZeistManga v5.5 Blogger template.

## ✨ Features

- 🌙 **Dark/Light Mode** - Toggle between dark and light themes
- 📚 **Bookmark System** - Save your favorite manga using localStorage
- 📖 **Chapter Reader** - Vertical scroll reader with navigation
- 📜 **Reading History** - Track chapter reading progress per manhwa
- 🎨 **Modern Design** - Beautiful UI converted from ZeistManga v5.5
- 📱 **Responsive** - Mobile-first responsive design
- 🔍 **Live Search** - Search manga by title with autocomplete
- 🏷️ **Genre Filtering** - Filter manga by genres
- 📊 **Status/Type Badges** - Ongoing, Completed, Manhwa, Manga badges
- ⭐ **Rating Display** - Show manga ratings
- 📢 **Ad Management** - Built-in ad slots for monetization
- 🔗 **SEO Friendly** - Clean URLs and proper meta tags

---

## 📋 Requirements

| Requirement               | Version           |
| ------------------------- | ----------------- |
| WordPress                 | 5.0+              |
| PHP                       | 7.4+              |
| MySQL                     | 5.6+              |
| **Manhwa Manager Plugin** | Latest (Required) |
| **Manhwa Scraper Plugin** | Latest (Optional) |

---

## 🚀 Installation

### Step 1: Upload Theme

**Option A: Via WordPress Admin**

1. Go to **Appearance → Themes → Add New → Upload Theme**
2. Upload `flavor-flavor.zip` file
3. Click **Install Now**

**Option B: Via FTP/File Manager**

1. Extract `flavor-flavor.zip`
2. Upload folder to `wp-content/themes/`
3. Ensure folder name is `flavor-flavor`

### Step 2: Install Required Plugin

> ⚠️ **IMPORTANT:** Theme requires **Manhwa Manager** plugin!

1. Go to **Plugins → Add New → Upload Plugin**
2. Upload `manhwa-manager.zip`
3. Click **Install Now** and **Activate**

### Step 3: Activate Theme

1. Go to **Appearance → Themes**
2. Find **Flavor Flavor** theme
3. Click **Activate**
4. Theme will auto-create required pages (Reader, Bookmarks)

### Step 4: Flush Permalinks

1. Go to **Settings → Permalinks**
2. Select **Post name** (recommended)
3. Click **Save Changes** (this flushes rewrite rules)

---

## ⚙️ Configuration Guide

### 1. Theme Colors

**Location:** Appearance → Customize → Theme Colors

| Setting         | Default   | Description                                |
| --------------- | --------- | ------------------------------------------ |
| Primary Color   | `#ff5722` | Main accent color (buttons, links, badges) |
| Secondary Color | `#ff5722` | Secondary accent color                     |

### 2. Hero Slider (Homepage)

**Location:** Appearance → Customize → Hero Slider

| Setting          | Default     | Options                                    |
| ---------------- | ----------- | ------------------------------------------ |
| Enable Slider    | ✅ On       | On/Off                                     |
| Slider Mode      | Most Viewed | Manual, Most Viewed, Highest Rated, Latest |
| Number of Slides | 8           | 3-15                                       |
| Auto-play Speed  | 5000ms      | 2000-10000ms                               |

**Tips:**

- **Manual Mode:** Requires setting manhwa as "Featured" via Manhwa Manager
- **Most Viewed:** Shows most popular based on view count
- **Latest:** Shows recently updated manhwa

### 3. Trending Widget (Sidebar)

**Location:** Appearance → Customize → Trending Widget

| Setting         | Default    | Description                           |
| --------------- | ---------- | ------------------------------------- |
| Widget Title    | "Trending" | Title shown on sidebar                |
| Sort By         | Most Views | Views, Rating, Latest, Random, Manual |
| Number of Manga | 5          | 1-20                                  |
| Show Tabs       | ✅ On      | Weekly/Monthly/All tabs               |
| Show Genres     | ✅ On      | Display genre tags                    |
| Show Rating     | ✅ On      | Display star ratings                  |
| Manual Post IDs | -          | Comma-separated IDs for manual mode   |

### 4. Contact Settings

**Location:** Appearance → Customize → Contact Settings

| Setting           | Description                                |
| ----------------- | ------------------------------------------ |
| Email Address     | Contact email for inquiries                |
| WhatsApp Number   | Include country code (e.g., +628123456789) |
| Telegram Username | Without @ symbol                           |

### 5. Ad Management

**Location:** Appearance → Customize → Ads Management

| Ad Slot       | Recommended Size | Position               |
| ------------- | ---------------- | ---------------------- |
| Header Ad     | 728x90           | Below header           |
| After Content | 728x90           | After main content     |
| Sidebar Ad    | 300x250          | In sidebar widget area |
| Before Footer | 728x90           | Above footer           |
| In-Article    | Responsive       | Inside chapter reader  |

**How to Add Ads:**

1. Paste your ad code (Google AdSense, etc.) into the textarea
2. HTML and JavaScript are supported
3. Check "Enable Advertisements" to show ads

### 6. Ad Slots (Contact Page)

**Location:** Appearance → Customize → Ad Slots

Configure 4 ad slots displayed on the contact page for advertisers:

- Name, Size, Description, Status (Available/Sold/Hidden)

---

## 📄 Required Pages Setup

### Reader Page (Auto-created)

The theme auto-creates a **Reader** page on activation. If missing:

1. Go to **Pages → Add New**
2. Title: `Reader`
3. Slug: `reader`
4. Page Template: **Chapter Reader**
5. Publish

### Bookmarks Page (Auto-created)

The theme auto-creates a **Bookmarks** page. If missing:

1. Go to **Pages → Add New**
2. Title: `Bookmarks`
3. Slug: `bookmarks`
4. Page Template: **Bookmarks**
5. Publish

### Contact Page

1. Go to **Pages → Add New**
2. Title: `Contact`
3. Slug: `contact`
4. Page Template: **Contact**
5. Publish

---

## 🧭 Menu Setup

**Location:** Appearance → Menus

### Primary Menu (Main Navigation)

1. Create new menu named "Primary Menu"
2. Add items:
   - Home (Link to homepage)
   - Manhwa List (Custom Link: `/manhwa/`)
   - Bookmarks (Link to Bookmarks page)
   - Contact (Link to Contact page)
3. Menu Settings: Check ✅ **Primary Menu**
4. Save Menu

### Footer Menu

1. Create new menu named "Footer Menu"
2. Add footer links (About, Privacy Policy, Terms, etc.)
3. Menu Settings: Check ✅ **Footer Menu**
4. Save Menu

---

## 📦 Widget Areas

**Location:** Appearance → Widgets

| Widget Area | Location              | Recommended Widgets      |
| ----------- | --------------------- | ------------------------ |
| Sidebar     | Right side of content | Trending, Search, Recent |
| Footer 1    | Left footer column    | About text, Social links |
| Footer 2    | Center footer column  | Quick links menu         |
| Footer 3    | Right footer column   | Newsletter, Contact info |

---

## 🔧 Manhwa Manager Plugin Settings

After installing Manhwa Manager plugin:

### Creating Manhwa

1. Go to **Manhwa → Add New Manhwa**
2. Fill in:
   - Title
   - Cover image (Featured Image)
   - Synopsis/Description
   - Type (Manhwa/Manga/Manhua)
   - Status (Ongoing/Completed/Hiatus)
   - Rating (1-10)
   - Alternative titles
   - Author/Artist
   - Genres

### Adding Chapters

1. Edit a Manhwa
2. Scroll to **Chapters** section
3. Add chapters with:
   - Chapter number/title
   - Release date
   - Image URLs (one per line)

### Setting Featured Manhwa

1. Edit a Manhwa
2. Check ✅ **Featured** option
3. This manhwa will appear in Hero Slider (Manual mode)

---

## 📁 Theme Structure

```
flavor-flavor/
├── assets/
│   ├── js/
│   │   └── theme.js          # Dark mode, bookmarks, search
│   └── images/
│       └── no-image.svg      # Placeholder image
├── style.css                  # Main stylesheet
├── functions.php              # Theme functions & customizer
├── header.php                 # Header template
├── footer.php                 # Footer template
├── front-page.php             # Homepage template
├── index.php                  # Blog index
├── single-manhwa.php          # Manhwa detail page
├── archive-manhwa.php         # Manhwa archive/list
├── taxonomy-manhwa_genre.php  # Genre archive
├── search.php                 # Search results
├── sidebar.php                # Sidebar widgets
├── single.php                 # Single post
├── page.php                   # Static page
├── page-contact.php           # Contact page template
├── 404.php                    # 404 error page
├── comments.php               # Comments template
├── template-chapter-reader.php # Chapter reader
├── template-bookmarks.php     # Bookmarks page
└── screenshot.png             # Theme preview
```

---

## 🔗 URL Structure

| Page           | URL Pattern                            |
| -------------- | -------------------------------------- |
| Homepage       | `/`                                    |
| Manhwa List    | `/manhwa/`                             |
| Single Manhwa  | `/manhwa/{slug}/`                      |
| Chapter Reader | `/reader/{manhwa-slug}/{chapter-num}/` |
| Genre Archive  | `/manhwa_genre/{genre-slug}/`          |
| Search         | `/search/?s={query}`                   |
| Bookmarks      | `/bookmarks/`                          |

---

## ❓ Troubleshooting

### Chapters not showing?

1. Go to **Settings → Permalinks**
2. Click **Save Changes** to flush rewrite rules
3. Clear browser cache

### 404 Error on chapter pages?

1. Deactivate and reactivate the theme
2. Go to **Settings → Permalinks** → Save Changes

### Images not loading?

1. Check if image URLs are valid
2. For external images, ensure the source allows hotlinking
3. Consider using Manhwa Scraper plugin to download images locally

### Slider not showing?

1. Check **Appearance → Customize → Hero Slider**
2. Ensure slider is enabled
3. For Manual mode: Mark at least one manhwa as "Featured"

---

## 📝 Credits

- Original Template: ZeistManga v5.5 by EmissionHex
- WordPress Conversion: Flavor
- Icons: Heroicons, Feather Icons
- Font: Poppins (Google Fonts)

---

## 📄 License

GNU General Public License v2 or later

---

## 🆘 Support

For issues and feature requests, please contact the theme developer or open an issue on the repository.
